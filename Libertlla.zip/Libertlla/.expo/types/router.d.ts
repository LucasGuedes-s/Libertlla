/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/BLEScanner`; params?: Router.UnknownInputParams; } | { pathname: `/Bluetooth`; params?: Router.UnknownInputParams; } | { pathname: `/Usuario`; params?: Router.UnknownInputParams; } | { pathname: `/botaodepanico`; params?: Router.UnknownInputParams; } | { pathname: `/horario`; params?: Router.UnknownInputParams; } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/processo`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/BLEScanner`; params?: Router.UnknownOutputParams; } | { pathname: `/Bluetooth`; params?: Router.UnknownOutputParams; } | { pathname: `/Usuario`; params?: Router.UnknownOutputParams; } | { pathname: `/botaodepanico`; params?: Router.UnknownOutputParams; } | { pathname: `/horario`; params?: Router.UnknownOutputParams; } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/processo`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/BLEScanner${`?${string}` | `#${string}` | ''}` | `/Bluetooth${`?${string}` | `#${string}` | ''}` | `/Usuario${`?${string}` | `#${string}` | ''}` | `/botaodepanico${`?${string}` | `#${string}` | ''}` | `/horario${`?${string}` | `#${string}` | ''}` | `/${`?${string}` | `#${string}` | ''}` | `/processo${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/BLEScanner`; params?: Router.UnknownInputParams; } | { pathname: `/Bluetooth`; params?: Router.UnknownInputParams; } | { pathname: `/Usuario`; params?: Router.UnknownInputParams; } | { pathname: `/botaodepanico`; params?: Router.UnknownInputParams; } | { pathname: `/horario`; params?: Router.UnknownInputParams; } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/processo`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; };
    }
  }
}
